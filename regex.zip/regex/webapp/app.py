from flask import Flask, render_template, request
import re

app = Flask(__name__)

@app.route('/')
def regex():
    return render_template('home.html')

@app.route('/result', methods=['GET', 'POST'])
def result():
    strtext = request.form['strtext']
    regex_pattern = request.form['regexpattern']
    if not strtext or not regex_pattern:
        return "Missing form fields", 400

    matches = re.findall(regex_pattern, strtext)
    return render_template('result.html', matches=matches)

if __name__ == '__main__':
    app.run( host="0.0.0.0", port = 5000, debug=True,)

